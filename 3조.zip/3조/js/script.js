// $(".menu").hover(
//   function(){
//     $(".sub-menu").stop().slideDown("slow");
//   },
//   function(){
//     $(".sub-menu").stop().slideUp("slow");
//   }
// );

// var slide = $(".slide>img");
// var sno = 0;
// var eno = slide.length - 1;

// setInterval("autoslide()", 3000);

// function autoslide(){
//   $(slide[sno]).stop().animate(
//     {left:"100%"}, 1000, function(){
//       $(this).css({left:"-100%"})
//     }
//   )
//   sno++;
//   if(sno>eno){sno=0;}
//   $(slide[sno]).stop().animate({left:"0%"}, 1000);
// }





// 공통 클릭 이벤트: 어떤 작품이든 data-target 읽어서 해당 팝업 열기
$("[data-target]").click(function () {
  var targetId = $(this).data("target");
  $(targetId).show();
});

// 닫기 함수
function closePop(selector) {
  $(selector).hide();
}